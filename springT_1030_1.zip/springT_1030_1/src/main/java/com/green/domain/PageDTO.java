package com.green.domain;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class PageDTO {
	private int startPage;
	private int endPage;
	private boolean prev, next;
	private int total;
	private Criteria crit;
	
	public PageDTO(Criteria crit, int total) {
	this.crit = crit;
	this.total=total;
	
	this.endPage = (int)(Math.ceil(crit.getPageNum()/10.0))*10;
	this.startPage = this.endPage - 9;
	
	//책 page 305
	int realEnd = (int)(Math.ceil((total*1.0)/crit.getAmount()));
	if(realEnd < this.endPage) {
		this.endPage = realEnd;
	}
	this.prev = this.startPage >1;
	
	this.next = this.endPage <realEnd;
	
	}

}
